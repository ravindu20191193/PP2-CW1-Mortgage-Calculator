import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.text.DecimalFormat;

public class Savings {

    // inputs

    public static Label NumberOfPeriods;
    public static Label StartPrincipal;
    public static Label InterestRate;
    public static Label MonthlyPayment;
    public static Label FutureValue;
    public static TextField NOP;
    public static TextField SP;
    public static TextField IR;
    public static TextField MP;
    public static TextField FV;
    public static Button Close;
    public static Button Calculate;

    // labels

    public static Label create_Lable(String promptText, double x, double y)
    {
        Label label = new Label(promptText);
        label.setLayoutX(x);
        label.setLayoutY(y);
        return label;
    }


    // text fields

    public static TextField create_Text_Field(String promptText, double x, double y, double scaleX, double scaleY)
    {
        TextField textField = new TextField();
        textField.setLayoutX(x);
        textField.setLayoutY(y);
        textField.setPrefWidth(scaleX);
        textField.setPrefHeight(scaleY);
        return textField;
    }


    // buttons

    public static Button create_Button(String Text, double x, double y, double scaleX, double scaleY)
    {
        Button button = new Button();
        button.setText(Text);
        button.setLayoutX(x);
        button.setLayoutY(y);
        button.setPrefWidth(scaleX);
        button.setPrefHeight(scaleY);
        return button;
    }


    // anchor pane

    public static AnchorPane create_Anchor_Pane(double x, double y){
        AnchorPane anchorPane = new AnchorPane();
        anchorPane.setLayoutX(x);
        anchorPane.setLayoutY(y);
        return anchorPane;
    }



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




    public static void SavingsWindow() {

        // Assigning Labels

        NumberOfPeriods = create_Lable("Number of Periods", 22, 64);
        StartPrincipal = create_Lable("Start Pricipal", 22, 103);
        InterestRate = create_Lable("Interest Rate", 22, 142);
        MonthlyPayment = create_Lable("Monthly Payment", 22, 181);
        FutureValue = create_Lable("Future Value",22,220);



        // Assigning TextFields

        NOP = create_Text_Field("years",170,60,148.8,25.6);
        SP = create_Text_Field("years",170,100,148.8,25.6);
        IR = create_Text_Field("%",170,140,148.8,25.6);
        MP = create_Text_Field("rupees",170,180,148.8,25.6);
        FV = create_Text_Field("rupees",170,220,148.8,25.6);



        //Assigning Buttons

        Close = create_Button("Close",22,544,94.4,46.4);
        Calculate = create_Button("Calculate",289,544,96.4,46.4);


        Pane Pane1 = new Pane();

        Pane1.getChildren().add(NumberOfPeriods);
        Pane1.getChildren().add(StartPrincipal);
        Pane1.getChildren().add(InterestRate);
        Pane1.getChildren().add(MonthlyPayment);


        Pane1.getChildren().add(NOP);
        Pane1.getChildren().add(SP);
        Pane1.getChildren().add(IR);
        Pane1.getChildren().add(MP);

        Pane1.getChildren().add(Close);
        Pane1.getChildren().add(Calculate);



        GridPane numPadPane3 = NumberPad.AddNumberPad(59,307,NOP,SP,IR,MP);
        numPadPane3.setPrefHeight(205);
        numPadPane3.setPrefWidth(296);
        Pane1.getChildren().add(numPadPane3);



        Stage savingsStage = new Stage();
        savingsStage.setTitle("Savings Calculator");
        savingsStage.setScene(new Scene(Pane1, 410,616));
        savingsStage.show();



        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


        // Calculations

        // (N) NOP - Number of Periods
        // (S) SP - Start Principal
        // (I) IR - Interest Rate
        // (M) MP - Monthly Payment

        Calculate.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                DecimalFormat decimalFormat = new DecimalFormat("#.##");

                if (FV.getText().equals("") && !SP.getText().equals("") && !IR.getText().equals("") && !NOP.getText().equals("")) { ;
                    double S = Double.parseDouble(SP.getText());
                    double I = Double.parseDouble(IR.getText());
                    double N = Double.parseDouble(NOP.getText());
                    double F = S * (Math.pow((1 + I / 100), N));
                    FV.setText(String.valueOf(decimalFormat.format(F)));

                }



                else if (SP.getText().equals("") && !FV.getText().equals("") && !IR.getText().equals("") && !NOP.getText().equals("")){
                    double I = Double.parseDouble(IR.getText());
                    double N = Double.parseDouble(NOP.getText());
                    double F = Double.parseDouble(FV.getText());
                    double S = F / (Math.pow((1 + I / 100), N));
                    SP.setText(String.valueOf(decimalFormat.format(S)));
                }



                else if (IR.getText().equals("") && !FV.getText().equals("") && !SP.getText().equals("") && !NOP.getText().equals("")) {
                    double S = Double.parseDouble(SP.getText());
                    double N = Double.parseDouble(NOP.getText());
                    double F = Double.parseDouble(FV.getText());
                    double I = 100 * ((Math.pow(F/S,1/N))-1);
                    IR.setText(String.valueOf(decimalFormat.format(I)));
                }



                else if (NOP.getText().equals("") && !FV.getText().equals("") && !SP.getText().equals("") && !IR.getText().equals("")) {
                    double S = Double.parseDouble(SP.getText());
                    double I = Double.parseDouble(IR.getText());
                    double F = Double.parseDouble(FV.getText());
                    double N = (Math.log(F) - Math.log(S)) / (Math.log(1 + I / 100));
                    NOP.setText(String.valueOf(decimalFormat.format(N)));
                }




            }
        });



        Close.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                NOP.setText("");
                SP.setText("");
                IR.setText("");
                MP.setText("");
                savingsStage.close();
                Pane1.getChildren().clear();
                numPadPane3.getChildren().clear();
            }
        });











    }
}