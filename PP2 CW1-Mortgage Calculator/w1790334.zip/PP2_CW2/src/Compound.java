import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.text.DecimalFormat;


public class Compound {

    // inputs

    public static Label FutureValue;
    public static Label StartPricipal;
    public static Label InterestRate;
    public static Label TimePeriod;
    public static TextField FV;
    public static TextField SP;
    public static TextField IR;
    public static TextField TP;

    public static Button Close;
    public static Button Calculate;



    // labels

    public static Label create_Lable(String promptText, double x, double y)
    {
        Label label = new Label(promptText);
        label.setLayoutX(x);
        label.setLayoutY(y);
        return label;
    }


    // text fields

    public static TextField create_Text_Field(String promptText, double x, double y, double scaleX, double scaleY)
    {
        TextField textField = new TextField();
        textField.setLayoutX(x);
        textField.setLayoutY(y);
        textField.setPrefWidth(scaleX);
        textField.setPrefHeight(scaleY);
        return textField;
    }


    // buttons

    public static Button create_Button(String Text, double x, double y, double scaleX, double scaleY)
    {
        Button button = new Button();
        button.setText(Text);
        button.setLayoutX(x);
        button.setLayoutY(y);
        button.setPrefWidth(scaleX);
        button.setPrefHeight(scaleY);
        return button;
    }


    // anchor pane

    public static AnchorPane create_Anchor_Pane(double x, double y){
        AnchorPane anchorPane = new AnchorPane();
        anchorPane.setLayoutX(x);
        anchorPane.setLayoutY(y);
        return anchorPane;
    }



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




    public static void CompoundWindow() {

        // Assigning Labels

        FutureValue = create_Lable("Future Value", 22, 64);
        StartPricipal = create_Lable("Start Principal", 22, 103);
        InterestRate = create_Lable("Interest Rate", 22, 142);
        TimePeriod = create_Lable("Time Period",22,184);


        // Assigning TextFields

        FV = create_Text_Field("rupees",170,60,148.8,25.6);
        SP = create_Text_Field("years",170,100,148.8,25.6);
        IR = create_Text_Field("%",170,140,148.8,25.6);
        TP = create_Text_Field("rupees",170,180,148.8,25.6);



        //Assigning Buttons

        Close = create_Button("Close",22,544,94.4,46.4);
        Calculate = create_Button("Calculate",289,544,96.4,46.4);



        Pane Pane1 = new Pane();

        Pane1.getChildren().add(FutureValue);
        Pane1.getChildren().add(StartPricipal);
        Pane1.getChildren().add(InterestRate);
        Pane1.getChildren().add(TimePeriod);

        Pane1.getChildren().add(FV);
        Pane1.getChildren().add(SP);
        Pane1.getChildren().add(IR);
        Pane1.getChildren().add(TP);

        Pane1.getChildren().add(Close);
        Pane1.getChildren().add(Calculate);

        GridPane numPadPane2 = NumberPad.AddNumberPad(59,307,FV, SP,IR,TP);
        numPadPane2.setPrefHeight(205);
        numPadPane2.setPrefWidth(296);
        Pane1.getChildren().add(numPadPane2);



        Stage compoundStage = new Stage();
        compoundStage.setTitle("Compound Calculator");
        compoundStage.setScene(new Scene(Pane1, 410,616));
        compoundStage.show();


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


        // Calculations


        // (F) FV - Future Value
        // (S) SP - Start Principal
        // (I) IR - Interest Rate
        // (T) TP - Time Period




        Calculate.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {


                DecimalFormat decimalFormat = new DecimalFormat("#.##");


                if (FV.getText().equals("") && !SP.getText().equals("") && !IR.getText().equals("") && !TP.getText().equals("")) { ;
                    double S = Double.parseDouble(SP.getText());
                    double I = Double.parseDouble(IR.getText());
                    double T = Double.parseDouble(TP.getText());
                    double F = S * (Math.pow((1 + I / 100), T));
                    FV.setText(String.valueOf(decimalFormat.format(F)));
                }

                else if (SP.getText().equals("") && !FV.getText().equals("") && !IR.getText().equals("") && !TP.getText().equals("")){
                    double I = Double.parseDouble(IR.getText());
                    double T = Double.parseDouble(TP.getText());
                    double F = Double.parseDouble(FV.getText());
                    double S = F / (Math.pow((1 + I / 100), T));
                    SP.setText(String.valueOf(decimalFormat.format(S)));
                }

                else if (IR.getText().equals("") && !FV.getText().equals("") && !SP.getText().equals("") && !TP.getText().equals("")) {
                    double S = Double.parseDouble(SP.getText());
                    double T = Double.parseDouble(TP.getText());
                    double F = Double.parseDouble(FV.getText());
                    double I = 100 * ((Math.pow(F/S,1/T))-1);
                    IR.setText(String.valueOf(decimalFormat.format(I)));
                }

                else if (TP.getText().equals("") && !FV.getText().equals("") && !SP.getText().equals("") && !IR.getText().equals("")) {
                    double S = Double.parseDouble(SP.getText());
                    double I = Double.parseDouble(IR.getText());
                    double F = Double.parseDouble(FV.getText());
                    double T = (Math.log(F)-Math.log(S))/(Math.log(1+I/100));
                    TP.setText(String.valueOf(decimalFormat.format(T)));
                }



                else{
                    Alert alert = new Alert(Alert.AlertType.NONE);
                    alert.setAlertType(Alert.AlertType.WARNING);
                    alert.setContentText("Input mandatory data and check the element you want is empty");
                    alert.showAndWait();
                }




            }
        });

        Close.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                FV.setText("");
                SP.setText("");
                IR.setText("");
                TP.setText("");
                compoundStage.close();
                Pane1.getChildren().clear();
                numPadPane2.getChildren().clear();
            }
        });













    }
}