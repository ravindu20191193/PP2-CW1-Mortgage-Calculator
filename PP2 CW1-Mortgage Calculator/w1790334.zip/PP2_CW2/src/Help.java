import javafx.scene.control.Label;


public class Help {

    public static void HelpWindow(){
        Label Label1 = new Label("Moratge");
    }
}


