import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;

import javax.swing.text.html.ImageView;

public class NumberPad {

    public static GridPane NumberPane = new GridPane();

    public static Button bt1 = addButton("1");
    public static Button bt2 = addButton("2");
    public static Button bt3 = addButton("3");
    public static Button bt4 = addButton("4");
    public static Button bt5 = addButton("5");
    public static Button bt6 = addButton("6");
    public static Button bt7 = addButton("7");
    public static Button bt8 = addButton("8");
    public static Button bt9 = addButton("9");
    public static Button bt0 = addButton("0");

    public static Button btDecimalPoint = addButton(".");
    public static Button btDelete = addButton("Delete");


    static boolean SelectText1 = false;
    static boolean SelectText2 = false;
    static boolean SelectText3 = false;
    static boolean SelectText4 = false;
    static boolean SelectText5 = false;

    private static void NumberPaneItems(double x, double y) {


        NumberPane.addColumn(0, bt1, bt4, bt7, btDelete);
        NumberPane.addColumn(1, bt2, bt5, bt8, bt0);
        NumberPane.addColumn(2, bt3, bt6, bt9, btDecimalPoint);
        NumberPane.setPrefWidth(186);
        NumberPane.setPrefHeight(207);
        NumberPane.setLayoutX(x);
        NumberPane.setLayoutY(y);
        NumberPane.setVgap(10.0);
        NumberPane.setHgap(10.0);
    }

    public static Button addButton(String text){
        Button button = new Button();
        button.setText(text);
        button.setPrefWidth(94);
        button.setPrefHeight(46);
        return button;
    }


    // Number pad for calculators which have 4 textfields.



    public static GridPane AddNumberPad(double x, double y, TextField field_1, TextField field_2, TextField field_3, TextField field_4) {

        NumberPaneItems(x, y);

        field_1.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                SelectText1 = true;
                SelectText2 = false;
                SelectText3 = false;
                SelectText4 = false;
                SelectText5 = false;

            }
        });

        field_2.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                SelectText1 = false;
                SelectText2 = true;
                SelectText3 = false;
                SelectText4 = false;
                SelectText5 = false;
            }
        });

        field_3.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                SelectText1 = false;
                SelectText2 = false;
                SelectText3 = true;
                SelectText4 = false;
                SelectText5 = false;
            }
        });

        field_4.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                SelectText1 = false;
                SelectText2 = false;
                SelectText3 = false;
                SelectText4 = true;
                SelectText5 = false;
            }
        });

        bt1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "1");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "1");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "1");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "1");

                }
            }
        });

        bt2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "2");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "2");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "2");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "2");

                }
            }
        });

        bt3.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "3");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "3");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "3");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "3");

                }
            }
        });

        bt4.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "4");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "4");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "4");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "4");

                }
            }
        });

        bt5.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "5");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "5");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "5");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "5");

                }
            }
        });

        bt6.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "6");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "6");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "6");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "6");

                }
            }
        });

        bt7.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "7");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "7");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "7");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "7");

                }
            }
        });

        bt8.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "8");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "8");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "8");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "8");

                }
            }
        });

        bt9.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "9");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "9");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "9");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "9");

                }
            }
        });

        bt0.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "0");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "0");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "0");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "0");

                }
            }
        });

        btDecimalPoint.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText()+".");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText()+".");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText()+".");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText()+".");

                }
            }
        });

        btDelete.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    String text = field_1.getText();

                    if (text.length() > 0) {
                        field_1.setText(text.substring(0, text.length() - 1));
                    }

                } else if (SelectText2) {

                    String text = field_2.getText();

                    if (text.length() > 0) {
                        field_2.setText(text.substring(0, text.length() - 1));
                    }

                } else if (SelectText3) {
                    String text = field_3.getText();

                    if (text.length() > 0) {
                        field_3.setText(text.substring(0, text.length() - 1));
                    }

                } else if (SelectText4) {
                    String text = field_4.getText();

                    if (text.length() > 0) {
                        field_4.setText(text.substring(0, text.length() - 1));
                    }

                }
            }
        });

        return NumberPane;

    }


    // Number pad for calculators which have 5 textfields.

    public static GridPane AddNumberPad(double x, double y, TextField field_1, TextField field_2, TextField field_3, TextField field_4, TextField field_5) {

        NumberPaneItems(x, y);

        field_1.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                SelectText1 = true;
                SelectText2 = false;
                SelectText3 = false;
                SelectText4 = false;
                SelectText5 = false;

            }
        });

        field_2.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                SelectText1 = false;
                SelectText2 = true;
                SelectText3 = false;
                SelectText4 = false;
                SelectText5 = false;
            }
        });

        field_3.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                SelectText1 = false;
                SelectText2 = false;
                SelectText3 = true;
                SelectText4 = false;
                SelectText5 = false;
            }
        });

        field_4.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                SelectText1 = false;
                SelectText2 = false;
                SelectText3 = false;
                SelectText4 = true;
                SelectText5 = false;
            }
        });

        field_5.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                SelectText1 = false;
                SelectText2 = false;
                SelectText3 = false;
                SelectText4 = false;
                SelectText5 = true;
            }
        });

        bt1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "1");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "1");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "1");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "1");

                } else if (SelectText5) {

                    field_5.setText(field_5.getText() + "1");

                }
            }
        });

        bt2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "2");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "2");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "2");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "2");

                } else if (SelectText5) {

                    field_5.setText(field_5.getText() + "2");

                }
            }
        });

        bt3.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "3");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "3");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "3");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "3");

                } else if (SelectText5) {

                    field_5.setText(field_5.getText() + "3");

                }
            }
        });

        bt4.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "4");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "4");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "4");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "4");

                } else if (SelectText5) {

                    field_5.setText(field_5.getText() + "4");

                }
            }
        });

        bt5.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "5");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "5");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "5");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "5");

                } else if (SelectText5) {

                    field_5.setText(field_5.getText() + "5");

                }
            }
        });

        bt6.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "6");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "6");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "6");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "6");

                } else if (SelectText5) {

                    field_5.setText(field_5.getText() + "6");

                }
            }
        });

        bt7.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "7");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "7");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "7");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "7");

                } else if (SelectText5) {

                    field_5.setText(field_5.getText() + "7");

                }
            }
        });

        bt8.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "8");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "8");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "8");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "8");

                } else if (SelectText5) {

                    field_5.setText(field_5.getText() + "8");

                }
            }
        });

        bt9.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "9");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "9");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "9");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "9");

                } else if (SelectText5) {

                    field_5.setText(field_5.getText() + "9");

                }
            }
        });

        bt0.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText() + "0");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText() + "0");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText() + "0");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText() + "0");

                } else if (SelectText5) {

                    field_5.setText(field_5.getText() + "0");

                }
            }
        });

        btDecimalPoint.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    field_1.setText(field_1.getText()+".");

                } else if (SelectText2) {

                    field_2.setText(field_2.getText()+".");

                } else if (SelectText3) {

                    field_3.setText(field_3.getText()+".");

                } else if (SelectText4) {

                    field_4.setText(field_4.getText()+".");

                } else if (SelectText5) {

                    field_5.setText(field_5.getText()+".");

                }
            }
        });

        btDelete.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (SelectText1) {

                    String text = field_1.getText();

                    if (text.length() > 0) {
                        field_1.setText(text.substring(0, text.length() - 1));
                    }

                } else if (SelectText2) {

                    String text = field_2.getText();

                    if (text.length() > 0) {
                        field_2.setText(text.substring(0, text.length() - 1));
                    }

                } else if (SelectText3) {
                    String text = field_3.getText();

                    if (text.length() > 0) {
                        field_3.setText(text.substring(0, text.length() - 1));
                    }

                } else if (SelectText4) {
                    String text = field_4.getText();

                    if (text.length() > 0) {
                        field_4.setText(text.substring(0, text.length() - 1));
                    }

                } else if (SelectText5) {

                    String text = field_5.getText();

                    if (text.length() > 0) {
                        field_5.setText(text.substring(0, text.length() - 1));

                    }
                }
            }
        });

        return NumberPane;
    }
}
