import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.text.DecimalFormat;


public class Loan {

    // inputs

    public static Label MonthlyPayment;
    public static Label LoanTerm;
    public static Label InterestRate;
    public static Label TotalLoanAmount;
    public static TextField MP;
    public static TextField LT;
    public static TextField IR;
    public static TextField TLA;
    public static TextField TIV;

    public static Button Close;
    public static Button Calculate;
    ;


    // labels

    public static Label create_Lable(String promptText, double x, double y)
    {
        Label label = new Label(promptText);
        label.setLayoutX(x);
        label.setLayoutY(y);
        return label;
    }


    // text fields

    public static TextField create_Text_Field(String promptText, double x, double y, double scaleX, double scaleY)
    {
        TextField textField = new TextField();
        textField.setLayoutX(x);
        textField.setLayoutY(y);
        textField.setPrefWidth(scaleX);
        textField.setPrefHeight(scaleY);
        return textField;
    }


    // buttons

    public static Button create_Button(String Text, double x, double y, double scaleX, double scaleY)
    {
        Button button = new Button();
        button.setText(Text);
        button.setLayoutX(x);
        button.setLayoutY(y);
        button.setPrefWidth(scaleX);
        button.setPrefHeight(scaleY);
        return button;
    }


    // anchor pane

    public static AnchorPane create_Anchor_Pane(double x, double y){
        AnchorPane anchorPane = new AnchorPane();
        anchorPane.setLayoutX(x);
        anchorPane.setLayoutY(y);
        return anchorPane;
    }



/////////////////////////////////////////////////////////////////////////////




    public static void LoanWindow() {

        // Assigning Labels

        MonthlyPayment = create_Lable("Monthly Paymenet", 22, 64);
        LoanTerm = create_Lable("Loan Term", 22, 103);
        InterestRate = create_Lable("Interest Rate", 22, 142);
        TotalLoanAmount = create_Lable("Total Loan Amount", 22, 181);


        // Assigning TextFields

        MP = create_Text_Field("rupees",170,60,148.8,25.6);
        LT = create_Text_Field("years",170,100,148.8,25.6);
        IR = create_Text_Field("%",170,140,148.8,25.6);
        TLA = create_Text_Field("rupees",170,180,148.8,25.6);



        //Assigning Buttons

        Close = create_Button("Close",22,544,94.4,46.4);
        Calculate = create_Button("Calculate",289,544,96.4,46.4);


        Pane Pane1 = new Pane();

        Pane1.getChildren().add(MonthlyPayment);
        Pane1.getChildren().add(LoanTerm);
        Pane1.getChildren().add(InterestRate);
        Pane1.getChildren().add(TotalLoanAmount);

        Pane1.getChildren().add(MP);
        Pane1.getChildren().add(LT);
        Pane1.getChildren().add(IR);
        Pane1.getChildren().add(TLA);


        Pane1.getChildren().add(Close);
        Pane1.getChildren().add(Calculate);


        GridPane numPadPane1 = NumberPad.AddNumberPad(59,307,MP,LT,IR,TLA);
        numPadPane1.setPrefHeight(205);
        numPadPane1.setPrefWidth(296);
        Pane1.getChildren().add(numPadPane1);





        Stage loanStage = new Stage();
        loanStage.setTitle("Loan Calculator");
        loanStage.setScene(new Scene(Pane1, 410,616));
        loanStage.show();



/////////////////////////////////////////////////////////////////////////////


        // Calculations


        // (A) AP - Auto Price
        // (L) LT - Loan Term
        // (I) IR - Interest Rate
        // (D) DP - Down Payment
        // (T) TIV - Trade-in Value



        Calculate.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                DecimalFormat decimalFormat = new DecimalFormat("#.##");


                if (MP.getText().equals("") && !TLA.getText().equals("") && !IR.getText().equals("") && !LT.getText().equals("")){
                    double P = Double.parseDouble(TLA.getText());
                    double I = (Double.parseDouble(IR.getText()))/12/100;
                    int T = 12 * (Integer.parseInt(LT.getText()));
                    double M = P * I * Math.pow(1 + I,T)/(Math.pow(1+I,T)-1);
                    MP.setText(String.valueOf(decimalFormat.format(M)));
                }

                else if (TLA.getText().equals("") && !MP.getText().equals("") && !IR.getText().equals("") && !LT.getText().equals("")){
                    double I = (Double.parseDouble(IR.getText()))/12/100;
                    int T = 12 * (Integer.parseInt(LT.getText()));
                    double M = Double.parseDouble(MP.getText());
                    double P = M * (Math.pow(1+I,T)-1)/ (I * Math.pow(1+I,T));
                    TLA.setText(String.valueOf(decimalFormat.format(P)));
                }

                else if (LT.getText().equals("") && !MP.getText().equals("") && !TLA.getText().equals("") && !IR.getText().equals("")) {
                    double I = (Double.parseDouble(IR.getText()))/12/100;
                    double M = Double.parseDouble(MP.getText());
                    double P = Double.parseDouble(TLA.getText());
                    double T = (Math.log((M/(M-((I/12)*(P-M))))))/(12*Math.log(1+(I/12)));
                    LT.setText(String.valueOf(decimalFormat.format(T)));
                }

                else if (IR.getText().equals("") && !MP.getText().equals("") && !TLA.getText().equals("") && !LT.getText().equals("")){
                    Alert alert = new Alert(Alert.AlertType.NONE);
                    alert.setAlertType(Alert.AlertType.INFORMATION);
                    alert.setContentText("Interest Rate Can't Be Empty.");
                    alert.showAndWait();
                }



                else {
                    Alert alert = new Alert(Alert.AlertType.NONE);
                    alert.setAlertType(Alert.AlertType.WARNING);
                    alert.setContentText("Input mandatory data and check the element you want is empty");
                    alert.showAndWait();
                }








            }
        });






        Close.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                MP.setText("");
                LT.setText("");
                IR.setText("");
                TLA.setText("");
                loanStage.close();
                Pane1.getChildren().clear();
                numPadPane1.getChildren().clear();
            }
        });









    }
}
