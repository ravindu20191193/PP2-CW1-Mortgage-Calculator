import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;


public class Main extends Application {

    public static Button button1;

    public static Button button2;

    public static Button button3;

    public static Button button4;

    public static Button helpBt;



    @Override
    public void start(Stage primaryStage) throws Exception {

        button1 = new Button();
        button1.setText("Mortgage Calculator");
        button1.setLayoutX(71);
        button1.setLayoutY(47);
        button1.setPrefHeight(100);
        button1.setPrefWidth(264);



        button2 = new Button();
        button2.setText("Savings Calculator");
        button2.setLayoutX(71);
        button2.setLayoutY(185);
        button2.setPrefHeight(100);
        button2.setPrefWidth(264);


        button3 = new Button();
        button3.setText("Auto Loan Calculator");
        button3.setLayoutX(71);
        button3.setLayoutY(320);
        button3.setPrefHeight(100);
        button3.setPrefWidth(264);


        button4 = new Button();
        button4.setText("Compound Savings Calculator");
        button4.setLayoutX(71);
        button4.setLayoutY(462);
        button4.setPrefHeight(100);
        button4.setPrefWidth(264);



        helpBt = new Button();
        helpBt.setText("?");
        helpBt.setLayoutX(364);
        helpBt.setLayoutY(14);
        helpBt.setPrefHeight(32);
        helpBt.setPrefWidth(32);


        Pane Pane1 = new Pane();

        Pane1.getChildren().add(button1);

        Pane1.getChildren().add(button2);

        Pane1.getChildren().add(button3);

        Pane1.getChildren().add(button4);

        Pane1.getChildren().add(helpBt);



        Stage stage = new Stage();
        stage.setTitle("Calculator");
        stage.setScene(new Scene(Pane1, 410,616));
        stage.show();

        button1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Mortgage.MortgageWindow();
            }
        });


        button2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Savings.SavingsWindow();
            }
        });


        button3.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent event) {
                Loan.LoanWindow();
            }
        });



        button4.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Compound.CompoundWindow();
            }
        });


        helpBt.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Help.HelpWindow();
            }
        });







    }


}
