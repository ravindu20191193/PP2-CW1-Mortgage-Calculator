import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.text.DecimalFormat;

public class Mortgage {


    // inputs

    public static Label HomePrice;
    public static Label LoanTerm;
    public static Label InterestRate;
    public static Label MonthlyPayment;
    public static TextField HP;
    public static TextField LT;
    public static TextField IR;
    public static TextField MP;
    public static Button Close;
    public static Button Calculate;


    // labels

    public static Label create_Lable(String promptText, double x, double y)
    {
        Label label = new Label(promptText);
        label.setLayoutX(x);
        label.setLayoutY(y);
        return label;
    }


    // text fields

    public static TextField create_Text_Field(String promptText, double x, double y, double scaleX, double scaleY)
    {
        TextField textField = new TextField();
        textField.setLayoutX(x);
        textField.setLayoutY(y);
        textField.setPrefWidth(scaleX);
        textField.setPrefHeight(scaleY);
        return textField;
    }


    // buttons

    public static Button create_Button(String Text, double x, double y, double scaleX, double scaleY)
    {
        Button button = new Button();
        button.setText(Text);
        button.setLayoutX(x);
        button.setLayoutY(y);
        button.setPrefWidth(scaleX);
        button.setPrefHeight(scaleY);
        return button;
    }


    // anchor pane

    public static AnchorPane create_Anchor_Pane(double x, double y){
        AnchorPane anchorPane = new AnchorPane();
        anchorPane.setLayoutX(x);
        anchorPane.setLayoutY(y);
        return anchorPane;
    }



/////////////////////////////////////////////////////////////////////////////




    public static void MortgageWindow() {

        // Assigning Labels

        HomePrice = create_Lable("Home Price", 22, 64);
        LoanTerm = create_Lable("Loan Term", 22, 119);
        InterestRate = create_Lable("Interest Rate", 22, 167);
        MonthlyPayment = create_Lable("Monthly Payment", 22, 227);


        // Assigning TextFields

        HP = create_Text_Field("rupees",170,60,148.8,25.6);
        LT = create_Text_Field("years",170,115,148.8,25.6);
        IR = create_Text_Field("%",170,167,148.8,25.6);
        MP = create_Text_Field("rupees",170,223,148.8,25.6);


        //Assigning Buttons

        Close = create_Button("Close",22,544,94.4,46.4);
        Calculate = create_Button("Calculate",289,544,96.4,46.4);



        // Adding Items to pane

        Pane Pane1 = new Pane();

        Pane1.getChildren().add(HomePrice);
        Pane1.getChildren().add(LoanTerm);
        Pane1.getChildren().add(InterestRate);
        Pane1.getChildren().add(MonthlyPayment);

        Pane1.getChildren().add(HP);
        Pane1.getChildren().add(LT);
        Pane1.getChildren().add(IR);
        Pane1.getChildren().add(MP);

        Pane1.getChildren().add(Close);
        Pane1.getChildren().add(Calculate);


        GridPane numPadPane = NumberPad.AddNumberPad(59,307,HP,LT,IR,MP);
        numPadPane.setPrefHeight(205);
        numPadPane.setPrefWidth(296);
        Pane1.getChildren().add(numPadPane);


        Stage mortgageStage = new Stage();
        mortgageStage.setTitle("Mortgage Calculator");
        mortgageStage.setScene(new Scene(Pane1, 410,616));
        mortgageStage.show();


/////////////////////////////////////////////////////////////////////////////


        //Calculations


        // (H) HP - Home Price
        // (L) LT - Loan Term
        // (I) IR - Interest Rate
        // (M) MP - Monthly Payment


        Calculate.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {

                DecimalFormat decimalFormat = new DecimalFormat("#.##");

                if (MP.getText().equals("") && !HP.getText().equals("") && !LT.getText().equals("") && !IR.getText().equals("")) {
                    double H = Double.parseDouble(HP.getText());
                    double I = (Double.parseDouble(IR.getText())) / 12 / 100;
                    int L = 12 * (Integer.parseInt(LT.getText()));
                    double M = H * I * Math.pow(1 + I, L) / (Math.pow(1 + I, L) - 1);
                    MP.setText(String.valueOf(decimalFormat.format(M)));
                }

                else if (HP.getText().equals("") && !LT.getText().equals("") && !IR.getText().equals("") && !MP.getText().equals("")) {
                    double M = Double.parseDouble(MP.getText());
                    double I = (Double.parseDouble(IR.getText())) / 12 / 100;
                    int L = 12 * (Integer.parseInt(LT.getText()));
                    double H = M * (Math.pow(1 + I, L) - 1) / (I * Math.pow(1 + I, L));
                    HP.setText(String.valueOf(decimalFormat.format(H)));
                }



                else if (LT.getText().equals("") && !HP.getText().equals("") && !MP.getText().equals("") && !IR.getText().equals("")) {
                    double I = (Double.parseDouble(IR.getText())) / 12 / 100;
                    double M = Double.parseDouble(MP.getText());
                    double H = Double.parseDouble(HP.getText());
                    double L = (Math.log((M / (M - ((I / 12) * (H - M)))))) / (12 * Math.log(1 + (I / 12)));
                    LT.setText(String.valueOf(decimalFormat.format(L)));
                }

                else if (IR.getText().equals("") && !HP.getText().equals("") && !LT.getText().equals("") && !MP.getText().equals("")) {
                    Alert alert = new Alert(Alert.AlertType.NONE);
                    alert.setAlertType(Alert.AlertType.INFORMATION);
                    alert.setContentText("Interest Rate Can't Be Empty.");
                    alert.showAndWait();
                }




            }
        });




       Close.setOnAction(new EventHandler<ActionEvent>() {
           @Override
           public void handle(ActionEvent event) {
              HP.setText("");
              LT.setText("");
              IR.setText("");
              MP.setText("");
              mortgageStage.close();
              Pane1.getChildren().clear();
              numPadPane.getChildren().clear();

            }
        });












    }
}
